package com.example.mafei.viewmanager.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.mafei.viewmanager.R;

/**
 * Created by mafei on 2017/2/13.
 */

public class TabButton extends LinearLayout implements ITabTitle {

    protected ImageView mContentImageView;
    protected LinearLayout mTabLayout;
    protected int mTextSzie;

    protected TextView mContentTextView;
    protected Context mContext;
    protected FrameLayout mFrameLayout;
    protected ImageView mTextView = null;

    private ITitleData mData;

    public TabButton(Context context) {
        super(context);
        mTextSzie = 12;
        mContext = context;
        setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT, 1.0f));
        setOrientation(VERTICAL);
        initContainer();
    }

    public TabButton(Context context, int textSize) {
        super(context);
        mTextSzie = textSize;
        mContext = context;
        setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT, 1.0f));
        setOrientation(VERTICAL);
        setBackgroundColor(Color.WHITE);
        initContainer();
    }

    private void initContainer() {
        mFrameLayout = new FrameLayout(mContext);
        LayoutParams frameLayoutParams = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT, 1.0f);
        mFrameLayout.setLayoutParams(frameLayoutParams);

        mTabLayout = new LinearLayout(mContext);
        int padding = (int) getResources().getDimension(R.dimen.DIP_3);
        setTabLayoutPadding(padding);
        LayoutParams tabLayoutParams = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
        mTabLayout.setLayoutParams(tabLayoutParams);
        mTabLayout.setGravity(Gravity.CENTER);
        mTabLayout.setOrientation(VERTICAL);

        mContentImageView = new ImageView(mContext);
        LayoutParams contentImageParams = new LayoutParams(LayoutParams.FILL_PARENT, 0,1.0f);

        contentImageParams.topMargin = (int) getResources().getDimension(R.dimen.DIP_3);
        mContentImageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        mContentImageView.setLayoutParams(contentImageParams);

        mContentTextView = new TextView(mContext);
        LayoutParams contentTextParams = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
        contentTextParams.topMargin = (int) getResources().getDimension(R.dimen.DIP_4);
        mContentTextView.setLayoutParams(contentTextParams);
        mContentTextView.setTextColor(mContext.getResources().getColor(R.color.tab_normal_color));
        mContentTextView.setTextSize(mTextSzie);
        mContentTextView.setIncludeFontPadding(false);
        mContentTextView.setGravity(Gravity.CENTER);

        mTabLayout.addView(mContentImageView);
        mTabLayout.addView(mContentTextView);

        mFrameLayout.addView(mTabLayout);

        mTextView = new ImageView(mContext);
        int width = PhoneInfoUtils.getScreenWidth(mContext);
        FrameLayout.LayoutParams textParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        textParams.gravity = Gravity.CENTER;
        setTextRightMarign(textParams, width);
        setTextBottomMargin(textParams);
        mTextView.setLayoutParams(textParams);
        mTextView.setBackgroundResource(R.drawable.superscript_bg);
        mTextView.setVisibility(View.GONE);

        mFrameLayout.addView(mTextView);
        addView(mFrameLayout);
    }

    protected void setTextBottomMargin(FrameLayout.LayoutParams textParams) {
        textParams.bottomMargin = (int) getResources().getDimension(R.dimen.DIP_19);
    }

    /**
     *
     * @param padding
     */
    protected void setTabLayoutPadding(int padding) {
        mTabLayout.setPadding(0, padding, 0, 0);
    }

    /**
     *
     * @param textParams
     * @param width
     */
    protected void setTextRightMarign(FrameLayout.LayoutParams textParams, int width) {
        textParams.leftMargin = (int) getResources().getDimension(R.dimen.DIP_12);
    }

    public void setText(String text) {
        mContentTextView.setText(text);
    }

    /**
     * 设置普通或高亮背景
     *
     * @param norDrawable
     * @param hlDrawable
     * @return
     */
    public static StateListDrawable getStateListDrawable(Drawable norDrawable, Drawable hlDrawable) {
        StateListDrawable bg = new StateListDrawable();
        bg.addState(View.PRESSED_ENABLED_STATE_SET, hlDrawable);
        bg.addState(View.ENABLED_FOCUSED_STATE_SET, hlDrawable);
        bg.addState(View.ENABLED_STATE_SET, norDrawable);
        bg.addState(View.PRESSED_FOCUSED_SELECTED_STATE_SET, hlDrawable);
        bg.addState(View.FOCUSED_STATE_SET, hlDrawable);
        bg.addState(View.EMPTY_STATE_SET, norDrawable);
        return bg;
    }

    @Override
    public void setState(int state) {
        if (TitleState.isSelected(state)) {
            setSelectedState();
        } else {
            setNormalState();
        }
    }

    protected void setNormalState() {
        Drawable image = mData.getNorDarawable();
        if (image != null) {
            mContentImageView.setImageDrawable(image);
            mContentImageView.setVisibility(View.VISIBLE);
        } else {
            mContentImageView.setVisibility(View.GONE);
        }
        Resources resources = mContext.getResources();
        mContentTextView.setTextColor(resources.getColor(R.color.tab_normal_text_color));
    }

    protected void setSelectedState() {
        Drawable pressedDrawable = mData.getSelecDrawable();
        if (pressedDrawable != null) {
            mContentImageView.setImageDrawable(pressedDrawable);
        }
        Resources resources = mContext.getResources();
        mContentTextView.setTextColor(resources.getColor(R.color.tab_pressed_color));
    }

    @Override
    public View getView() {
        return this;
    }

    @Override
    public void setTitleData(ITitleData data) {
        mData = data;
        setState(TitleState.STATE_NORMAL);
        if (mData.getTitle() != null) {
            setText(mData.getTitle());
        }
    }

    @Override
    public void light() {
        mTextView.setVisibility(View.VISIBLE);
    }

    @Override
    public void cancelLight() {
        if (mTextView != null) {
            mTextView.setVisibility(View.GONE);
        }
    }
}
