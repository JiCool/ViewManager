package com.example.mafei.viewmanager;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.mafei.viewmanager.view
        .ITabTitle;
import com.example.mafei.viewmanager.view.ScrollTabButton;
import com.example.mafei.viewmanager.view
        .TabButton;

/**
 * Created by mafei on 2017/2/13.
 */

public class TabTitleBuildFactory {
    public static final int STYLE_MAIN_UT = 1;


    public static final int STYLE_SUB_UI = 2;


    public static ITabTitle getTabTitle(Context context, int style) {

        switch (style) {
            case STYLE_MAIN_UT:
                return new TabButton(context);
            case STYLE_SUB_UI:
                return new ScrollTabButton(context);
            default:
                break;
        }
        return null;
    }

    public static View getTitleDivider(Context context, int style) {
        switch (style) {
            case STYLE_SUB_UI:
                ImageView separateImageView =
                        null;
                Drawable separateDrawable = context.getResources().getDrawable(R.drawable.setting_list_separate);
                int width = (int) context.getResources().getDimension(R.dimen.common_list_divider_height);
                int height = (int) context.getResources().getDimension(R.dimen.tab_top_title_divider_height);
                separateImageView = new ImageView(context);
                LinearLayout.LayoutParams separateImageParams = new LinearLayout.LayoutParams(width, height);
                separateImageParams.gravity = Gravity.CENTER;
                separateImageView.setLayoutParams(separateImageParams);
                separateImageView.setBackgroundDrawable(separateDrawable);
                return separateImageView;
            default:
                break;
        }
        return null;
    }
}
