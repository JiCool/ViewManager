package com.example.mafei.viewmanager.view;

/**
 * Created by mafei on 2017/1/12.
 */
public class ViewType {
    public static final int INVALID = -1;

    public static final int TYPE_MASK = 0xff00;

    public static final int SPLASH = 0x0300;

    public static int getMainType(Class<?> cla) {
        if(cla == null)
        {
            return INVALID;
        }
        return cla.getClass().hashCode();
    }
}
