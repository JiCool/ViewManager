package com.example.mafei.viewmanager.view;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by mafei on 2017/2/13.
 */

public class BasicInfo implements Parcelable {

    protected int mType;
    protected long mRequestId;
    protected boolean mSuccessful;
    protected String mDesc;
    protected String mStatusCode;

    public BasicInfo() {

    }

    public String getStatusCode() {
        return mStatusCode;
    }

    public void setStatusCode(String status) {
        mStatusCode = status;
    }

    public boolean isSuccessful() {
        return mSuccessful;
    }

    public void setSuccessful(boolean successful) {
        mSuccessful = successful;
    }

    public String getDesc() {
        return mDesc;
    }

    public void setDesc(String desc) {
        mDesc = desc;
    }

    public void setType(int type) {
        this.mType = type;
    }

    public int getType() {
        return mType;
    }

    public void setRequestId(long requestId) {
        this.mRequestId = requestId;
    }

    public long getRequestId() {
        return mRequestId;
    }
    public static final Parcelable.Creator<BasicInfo> CREATOR = new Parcelable.Creator<BasicInfo>() {

        @Override
        public BasicInfo createFromParcel(Parcel in) {
            return new BasicInfo(in);
        }

        @Override
        public BasicInfo[] newArray(int size) {
            return new BasicInfo[size];
        }
    };

    public BasicInfo(Parcel in) {
        mType = in.readInt();
        mRequestId = in.readLong();
        mSuccessful = in.readInt() == 1;
        mDesc = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mType);
        dest.writeLong(mRequestId);
        dest.writeInt(mSuccessful ? 1 : 0);
        dest.writeString(mDesc);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
