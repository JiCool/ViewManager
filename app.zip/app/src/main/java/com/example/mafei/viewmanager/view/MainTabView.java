package com.example.mafei.viewmanager.view;

import android.content.Context;
import android.os.Handler;
import android.view.View;

import com.example.mafei.viewmanager
        .OnOperationResultListener;
import com.example.mafei.viewmanager
        .TabLightCancelListener;
import com.example.mafei.viewmanager.manager
        .interfaces.IViewManager;
import com.example.mafei.viewmanager.navigator.ITabHostContentView;

import java.util.ArrayList;

/**
 * Created by mafei on 2017/2/13.
 */

public class MainTabView extends BaseView
        implements TabLightCancelListener,
        OnOperationResultListener {

//    private static final int DEF_SWITCH_TYPT
// = iewType.TAB_MORE_SETTING;

    private static final int
            DEF_TAB_APP_LIGHT_EXPIRE_DAY = 1;

    private static final int MSG_LIGHT_APP = 1;

    private static final int MSG_INIT_VIEW = 2;

    private ITabView mTabView;

    private MyIntent mIntent;

    private IViewManager mViewManager;

    private ArrayList<ITabHostContentView> mSubViews;


//    private IOperationManager mOperationManager;

    private boolean mVisiable;

    private Handler mHandler = new Handler() {
        public void handleMessage(android.os
                                          .Message msg) {
            switch (msg.what) {
                case MSG_LIGHT_APP:
//                    lightTabApp();
                    break;
                case MSG_INIT_VIEW:
                    initView();
                    break;
                default:
                    break;
            }

        }
    };

    public MainTabView(Context context,
                       IViewManager viewManager) {
        super(context, viewManager);
        mViewManager = viewManager;

        mTabView = new TabView(mContext,
                TabView.STYLE_TITLE_BOTTOM);

//         buildTabView();
    }

    private void buildTabView() {
        mTabView.removeAllSubView();
        mSubViews = new ArrayList<ITabHostContentView>();
        ScrollTabViewContainer themeSetting = new
                ScrollTabViewContainer(mContext,
                mViewManager);
        mSubViews.add(themeSetting);



        SubTabView2 moreSetting = new
                SubTabView2(mContext,
                mViewManager);

        mSubViews.add(moreSetting);

        for (ITabHostContentView subView : mSubViews) {
            mTabView.addSubView(subView);
        }

    }

    private int getIndex(Class<?> cla) {
        if (mSubViews == null) {
            return -1;
        }
        for (int i = 0; i < mSubViews.size();
             i++) {
            if (mSubViews.get(i).getClass().getName().equals(cla.getName())) {
                return i;
            }
        }
        return -1;
    }

    public void switchViewForType(Class cla,
                                  MyIntent intent) {
//        int viewCode = code;
        int index = -1;

        index = getIndex(cla);
        if (index == -1) {
            index = mSubViews.size() - 1;
        }

        if (intent == null) {
            intent = new MyIntent();
        }

//        intent.putExtra(SettingLauncher
//                .EXTRA_VIEW_TYPE, type);

        mTabView.switchToSubView(index, intent);
    }


//        return SettingViewType.SETTING_TAB;


    @Override
    public View getView() {
        return mTabView.getTabView();
    }

    @Override
    public void resumeView() {
        mVisiable = true;

            initView();
    }
public static String VIEW_HASH_Code = "VIEW_HASH_Code";
    private void handleResume() {
        if (mIntent != null) {
            int viewHashCode = mIntent.getIntExtra
                    (VIEW_HASH_Code,
                            ViewType
                                    .INVALID);
//            if (viewHashCode != ViewType
//                    .INVALID) {
//
//                    switchViewForType(viewHashCode,
//                            mIntent);
//
//            }else {
                if(mSubViews.size() <= 0)
                {
                    throw new RuntimeException("There is not Sub Tab View");
                }
                switchViewForType(mSubViews.get(0).getClass(),
                        mIntent);
//            }
        }
        else {
            if(mSubViews.size() <= 0)
            {
                throw new RuntimeException("There is not Sub Tab View");
            }
            switchViewForType(mSubViews.get(0).getClass(),
                    mIntent);
        }
        mTabView.resumeView();
    }

    private void handleLightApp() {

//        boolean isFirstInstall = true;
//        boolean light = false;
//        // 第一次安装点亮
//        if (isFirstInstall) {
//            light = true;
//
//        } else {
//                light = false;
//        }
//
//        if (light) {
//            lightTabApp();
//        } else {
//            cancelLight(SettingViewType.APP_REC);
//        }


    }

//    private void lightTabApp() {
//        mTabView.lightenSubTab(getIndex
//                (SettingViewType
//                        .getTabParentType
//                                (SettingViewType.APP_REC)));
//
//    }



    @Override
    public void hideView() {
        mVisiable = false;
        mTabView.hideView();
    }

    @Override
    public void destroyView() {

        mHandler.removeCallbacksAndMessages(null);

        mTabView.destroyView();
    }

    @Override
    public View createView() {
        return null;
    }

    @Override
    public void createView(MyIntent intent) {
        mTabView.createView(intent);
    }



    private void initView() {
        // 只创建一次
        if (mSubViews == null) {
            buildTabView();
            handleLightApp();
        }
        handleResume();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        mTabView.onRequestPermissionsResult
                (requestCode, permissions,
                        grantResults);
    }

    @Override
    public void cancelLight(int type) {

//        int parentType = SettingViewType
//                .getTabParentType(type);
//        int index = -1;
//        if (parentType != getViewType()) {
//            index = getIndex(parentType);
//        }
//
//        if (index != -1) {
//            mTabView.cancelLight(index);
//
//        }
    }

    @Override
    public void onResult(int errorCode,
                         BasicInfo result, long
                                     requestId,
                         int requestType) {
//        NetTabLightData tabLightData =
//                (NetTabLightData) result;
//        if (tabLightData != null) {
//            mMainService.setString
//                    (MainAbilitySettingKey
//                            .LAST_TAB_LIGHT_REQUEST_KEY, tabLightData.getTimeStamp());
//            ArrayList<NetTabLightDataItem>
//                    items = tabLightData
//                    .getNetTabLightItems();
//            if (HttpErrorCode.OK == errorCode
//                    && items != null && !items
//                    .isEmpty()) {
//                for (NetTabLightDataItem item :
//                        items) {
//                    if (item.getCoord() != null
//                            && item.getCoord()
//                            .startsWith
//                                    (SettingConstants.APP_RECOMMEND_TAB_COORD)) {
//                        if (item.getLight() !=
//                                null && item
//                                .getLight()
//                                .equals(SettingConstants.APP_LIGHT)) {
//                            if (item.getText()
//                                    != null) {
//                                mMainService
//                                        .setString(MainAbilitySettingKey.TAB_APP_LIGHT_TOAST, item.getText());
//                            }
//                            mMainService
//                                    .setBoolean
//                                            (MainAbilitySettingKey.TAB_APP_LIGHT_KEY, true);
//                            mMainService
//                                    .setString
//                                            (MainAbilitySettingKey.LAST_TAB_LIGHT_REQUEST_KEY,
//                                    item.getTimeStamp());
//                            mMainService.setInt
//                                    (MainAbilitySettingKey.TAB_APP_LIGHT_EXPIRE_DAY_KEY,
//                                    item.getExpire() == null ? DEF_TAB_APP_LIGHT_EXPIRE_DAY
//                                            : Integer.parseInt(item.getExpire()));
//                            mHandler.sendEmptyMessage(MSG_LIGHT_APP);
//                        }
//
//                    }
//                }
//            }
        }
    }
