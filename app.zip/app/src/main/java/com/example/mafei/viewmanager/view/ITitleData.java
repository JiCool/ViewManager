package com.example.mafei.viewmanager.view;

import android.graphics.drawable.Drawable;

/**
 * Created by mafei on 2017/2/13.
 */

public interface ITitleData {
    String getTitle();

    Drawable getNorDarawable();

    Drawable getSelecDrawable();
}
