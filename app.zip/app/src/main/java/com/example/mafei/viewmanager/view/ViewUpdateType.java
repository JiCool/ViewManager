package com.example.mafei.viewmanager.view;

/**
 * Created by mafei on 2017/2/24.
 */

public enum ViewUpdateType {
    Enter,Exit
}
