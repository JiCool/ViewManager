package com.example.mafei.viewmanager.view;

import android.view.View;

import com.example.mafei.viewmanager.navigator.ITabHostContentView;
import com.example.mafei.viewmanager.view
        .interfaces.IBaseView;

/**
 * Created by mafei on 2017/2/13.
 */

public interface ITabView extends IBaseView {

    void addSubView(ITabHostContentView subTabView);

    void addSubView(int index, ITabHostContentView subTabView);

    void removeSubView(ITabHostContentView subTabView);

    void removeAllSubView();

    void removeSubView(int index);

    void switchToSubView(int index);

    void switchToSubView(int index, MyIntent intent);

    /**
     * 点亮subtab
     *
     * @param index
     */
    void lightenSubTab(int index);

    void cancelLight(int index);

    View getTabView();

}
