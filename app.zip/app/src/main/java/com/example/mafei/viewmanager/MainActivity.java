package com.example.mafei.viewmanager;

import android.os.Bundle;
import android.os.Debug;
import android.widget.Toast;

import com.example.mafei.viewmanager.manager
        .ViewFlags;
import com.example.mafei.viewmanager.navigator.TabHostTest;
import com.example.mafei.viewmanager.scroll_navigator.ScrollTabHostTest;
import com.example.mafei.viewmanager.scroll_navigator.ScrollTabHostTest1;
import com.example.mafei.viewmanager.test.View1;
import com.example.mafei.viewmanager.view
        .MainTabView;
import com.example.mafei.viewmanager.view
        .MyIntent;

public class MainActivity extends ViewActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        Debug.waitForDebugger();
        MyIntent intent = new MyIntent();
//        intent.setClass(this, TestActivity2.class);
        intent.setViewClass(TabHostTest.class);
//        intent.setViewClass(ScrollTabHostTest1.class);

        intent.setViewFlag(ViewFlags.FLAG_VIEW_NEW_TASK);
//        Debug.waitForDebugger();
        Toast.makeText(this,"this is "+getLocalClassName(),Toast.LENGTH_SHORT).show();
       startViewActivity(intent);
    }
}
