package com.example.mafei.viewmanager.view.util;

/**
 * Created by mafei on 2017/1/12.
 */
public class ViewAnimUtil {
    /**
     * 界面进入
     */
    public static final int ACTION_ENTER = 1;

    /**
     * 界面退出
     */
    public static final int ACTION_EXIT = 2;
}
