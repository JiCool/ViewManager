package com.example.mafei.viewmanager.view.interfaces;

import android.view.View;

/**
 * Created by mafei on 2017/2/21.
 */

public interface IViewAnimation {
    void startAnimation(int action,View fromView,View toView);
}
