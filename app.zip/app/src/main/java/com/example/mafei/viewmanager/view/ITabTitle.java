package com.example.mafei.viewmanager.view;

import android.view.View;

/**
 * Created by mafei on 2017/2/13.
 */

public interface ITabTitle {

    void setState(int state);

    void setTitleData(ITitleData data);

    View getView();

    void light();

    void cancelLight();
}
