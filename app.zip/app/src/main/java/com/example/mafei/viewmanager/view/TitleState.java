package com.example.mafei.viewmanager.view;

/**
 * Created by mafei on 2017/2/13.
 */

public class TitleState {


    public static final int STATE_MASK = 0xff0;

    public static final int STATE_NORMAL = 0x000;

    public static final int STATE_SELECTED = 0x010;

    public static boolean isSelected(int state) {
        return (state & STATE_MASK) == STATE_SELECTED;
    }
}
