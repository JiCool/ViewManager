package com.example.mafei.viewmanager.view.interfaces;

/**
 * Created by mafei on 2017/2/23.
 */

public interface IViewResult {
}
