package com.example.mafei.viewmanager.navigator;

import android.content.Intent;
import android.view.View;

import com.example.animationlibrary.library.Animators;
import com.example.mafei.viewmanager.view.MyIntent;
import com.example.mafei.viewmanager.view
        .interfaces.IBaseView;

/**
 * Created by mafei on 2017/2/13.
 */

public interface ITabHostContentView extends IBaseView {

    boolean isSelected();

    /**
     * 被切换到此subview
     */
    void onSelected(MyIntent intent);

    /**
     * 被切走
     */
    void onUnSelected();

}
