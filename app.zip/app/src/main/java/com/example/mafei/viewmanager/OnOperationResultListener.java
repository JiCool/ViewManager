package com.example.mafei.viewmanager;

import com.example.mafei.viewmanager.view
        .BasicInfo;

/**
 * Created by mafei on 2017/2/13.
 */

public interface OnOperationResultListener {
    void onResult(int errorCode, BasicInfo result, long requestId, int requestType);
}
