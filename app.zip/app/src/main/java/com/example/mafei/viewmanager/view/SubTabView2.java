package com.example.mafei.viewmanager.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import com.example.mafei.viewmanager.R;
import com.example.mafei.viewmanager.manager
        .interfaces.IViewManager;
import com.example.mafei.viewmanager.navigator.BaseTabHostContentView;

/**
 * Created by mafei on 2017/2/14.
 */

public class SubTabView2 extends BaseTabHostContentView {



    @Override
    public void onSelected(MyIntent intent) {

    }

    @Override
    public void onUnSelected() {

    }


    @Override
    public View getView() {
        return mContentView;
    }




    @Override
    public void resumeView() {

    }

    @Override
    public void hideView() {

    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

    }

    @Override
    public void setIntent(MyIntent intent) {

    }


    public SubTabView2(Context context, IViewManager viewManager) {
        super(context,viewManager);
        mContext = context;

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        mContentView = (LinearLayout) layoutInflater.inflate(R.layout.subtabview_two, null);
//        mThemeTabView = new PageTabView(mContext, PageTabView.STYLE_TITLE_TOP);
//        mThemeTabView.setTabTitleStyle(TabTitleBuildFactory.STYLE_SUB_UI);
//        mThemeTabView.setOnPageChangeListener(this);
//
//        mMainService = (MainAbilityService) AppComm.register(mContext, BusinessServiceName.MAIN_SERVICE);
//        mAssistService = (AssistProcessService) AppComm.register(mContext, BusinessServiceName.BACKGROUD_SERVICE);
//
//        mSkinDataManager = (SettingSkinDataService) AppComm.register(mContext,
//                BusinessServiceName.SETTING_SKIN_SERVICE);
//
//        buildTabView();
    }
}
