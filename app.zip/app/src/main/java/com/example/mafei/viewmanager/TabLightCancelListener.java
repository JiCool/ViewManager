package com.example.mafei.viewmanager;

/**
 * Created by mafei on 2017/2/13.
 */

public interface TabLightCancelListener {
    public void cancelLight(int type);
}

