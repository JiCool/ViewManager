package com.example.mafei.viewmanager.app;

import android.app.Application;
import android.util.Log;

import com.example.mafei.viewmanager.parser
        .PullViewParser;

import java.io.InputStream;

/**
 * Created by mafei on 2017/1/12.
 */
public class BaseApplication extends Application{
    @Override
    public void onCreate() {
        super.onCreate();
    }



}
