package com.example.mafei.viewmanager.view;

/**
 * Created by mafei on 2017/2/22.
 */

public enum ViewLaunchMode {
    Standard,SingleTask,SingleInstance;
}
