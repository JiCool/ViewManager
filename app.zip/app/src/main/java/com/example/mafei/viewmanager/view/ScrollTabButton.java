package com.example.mafei.viewmanager.view;

import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;

import com.example.mafei.viewmanager.R;

/**
 * Created by mafei on 2017/2/20.
 */

public class ScrollTabButton extends TabButton {

    private ImageView mSelectedImageView;

    public ScrollTabButton(Context context) {
        super(context, 16);
        mContentImageView.setVisibility(View.GONE);
        LayoutParams contentTextParams = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
        mContentTextView.setLayoutParams(contentTextParams);
        setTabLayoutPadding(0);
    }

    @Override
    public void setSelectedState() {
        createSelectedImageView();
        mSelectedImageView.setVisibility(View.VISIBLE);
        Resources resources = mContext.getResources();
        mContentTextView.setTextColor(resources.getColor(R.color.scroll_tab_pressed_text_color));
    }

    @Override
    public void setNormalState() {
        createSelectedImageView();
        mSelectedImageView.setVisibility(View.INVISIBLE);
        Resources resources = mContext.getResources();
        mContentTextView.setTextColor(resources.getColor(R.color.scroll_tab_normal_text_color));
    }

    private void createSelectedImageView() {
        if (mSelectedImageView == null) {
            mSelectedImageView = new ImageView(getContext());
            LayoutParams contentImageParams = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
            contentImageParams.gravity = Gravity.BOTTOM;
            mSelectedImageView.setLayoutParams(contentImageParams);
            mSelectedImageView.setBackgroundResource(R.drawable.scroll_tab_selected_bg);
            addView(mSelectedImageView);
        }
    }

}
