package com.example.mafei.viewmanager.scroll_navigator;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mafei.viewmanager.PageTabView;
import com.example.mafei.viewmanager.R;
import com.example.mafei.viewmanager.manager.interfaces.IViewManager;
import com.example.mafei.viewmanager.navigator.TabSpec;
import com.example.mafei.viewmanager.navigator.BaseTabHostContentView;
import com.example.mafei.viewmanager.view.MyIntent;
import com.example.mafei.viewmanager.view.ScrollSubTabView1;
import com.example.mafei.viewmanager.view.ViewPager;

/**
 * Created by mafei on 2017/2/27.
 */

public class ScrollTabHostTest extends BaseTabHostContentView implements ViewPager.OnPageChangeListener {


    private ScrollTabHost mScrollTabHost;
    MyIntent mIntent = null;
    private int mLastIndex;
    private String texts[] = {"测试1", "测试2"};
    private Class TabArray[] = {ScrollSubTabView1.class, ScrollSubTabView1.class};
    private int imageButton[] = {R.drawable.selector_me, R.drawable.selector_bill};

    public ScrollTabHostTest(Context context, IViewManager viewManager) {
        super(context, viewManager);
        mScrollTabHost = new ScrollTabHost(mContext, viewManager, PageTabView.STYLE_TITLE_TOP);
//        mScrollTabHost.setTabTitleStyle(TabTitleBuildFactory.STYLE_SUB_UI);
        mScrollTabHost.setOnPageChangeListener(this);
        initView();
    }

    @Override
    public void onSelected(MyIntent intent) {
        mSelected = true;
        if (intent != null) {
            mIntent = intent;
        }
        initView();
    }

    @Override
    public void resumeView() {
        super.resumeView();
        switchToTabView();
    }

    private void initView() {
        if(mScrollTabHost.isEmpty())
        {
            for (int i = 0; i < texts.length; i++) {
                TabSpec tabSpec = mScrollTabHost.newTabSpec();
//            tabSpec.setText(texts[i]);
//            Debug.waitForDebugger();
                tabSpec.setIndicator(getView(i, mContext));
//            Debug.waitForDebugger();
                mScrollTabHost.addTabContentView(tabSpec, TabArray[i]);
            }
        }
        switchToTabView();

    }

    private void switchToTabView() {
        int index = 0;
        boolean fromOther = true;

        MyIntent intent = new MyIntent();
        intent.putExtra(PageTabView.PAGETABVIEW_SWITCH_SMOOTH_SCROLL, false);
//        intent.putExtra(Constants.TAB_VIEW_BE_SWITCHED_FROM_OTHER, fromOther);
        mScrollTabHost.switchToTabContentView(index, intent);

        mLastIndex = index;
    }

    private View getView(int i, Context context) {
        //取得布局实例
        View view = View.inflate(context, R.layout.tabtitle, null);

        //取得布局对象
        ImageView imageView = (ImageView) view.findViewById(R.id.image);
        TextView textView = (TextView) view.findViewById(R.id.text);
        //设置图标
//        imageView.setBackgroundResource(imageButton[i]);
        imageView.setImageResource(imageButton[i]);
        imageView.setVisibility(View.INVISIBLE);
        //设置标题
        textView.setText(texts[i]);
        return view;
    }

    @Override
    public void onUnSelected() {
        mSelected = false;
        mScrollTabHost.hideView();
    }


    @Override
    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2) {

    }

    @Override
    public void onPageSelected(int paramInt) {

    }

    @Override
    public void onPageScrollStateChanged(int paramInt) {

    }

    @Override
    public View getView() {
        return mScrollTabHost;
    }
}
