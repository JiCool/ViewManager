package com.example.mafei.viewmanager.view;

import android.content.Context;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import com.example.mafei.viewmanager.PageTabView;
import com.example.mafei.viewmanager.R;
import com.example.mafei.viewmanager.TabTitleBuildFactory;
import com.example.mafei.viewmanager.manager
        .interfaces.IViewManager;
import com.example.mafei.viewmanager.navigator.BaseTabHostContentView;

/**
 * Created by mafei on 2017/2/13.
 */

public class ScrollTabViewContainer extends BaseTabHostContentView implements ViewPager.OnPageChangeListener {

    private LinearLayout mContentView;
    private boolean mSelected;
    private ScrollSubTabView1 scrollSubTabView1;
    private ScrollSubTabView2 scrollSubTabView2;
    private PageTabView mThemeTabView;
    /**
     * 类型索引映射表
     */
    private SparseArray<Integer> mTypeIndexMap;
    MyIntent mIntent = null;
    private int mLastIndex;

    @Override
    public void onSelected(MyIntent intent) {
        mSelected = true;
        if (intent != null) {
            mIntent = intent;
        }
        initView();
    }

    @Override
    public void onUnSelected() {
        mSelected = false;
        mThemeTabView.hideView();
    }



    @Override
    public View getView() {
        return mThemeTabView;
    }

    @Override
    public void createView(MyIntent intent) {
        if (intent != null) {
            mIntent = intent;
        }
    }

    @Override
    public void resumeView() {

    }


    @Override
    public void hideView() {

    }

    @Override
    public void destroyView() {
        if (null != mIntent) {
            mIntent = null;
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

    }

    @Override
    public void setIntent(MyIntent intent) {

    }


    public ScrollTabViewContainer(Context context, IViewManager viewManager) {
        super(context, viewManager);
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        mContentView = (LinearLayout) layoutInflater.inflate(R.layout.subview_one, null);
        mThemeTabView = new PageTabView(mContext, PageTabView.STYLE_TITLE_TOP);
        mThemeTabView.setTabTitleStyle(TabTitleBuildFactory.STYLE_SUB_UI);
        mThemeTabView.setOnPageChangeListener(this);
//        mThemeTabView = new PageTabView(mContext, PageTabView.STYLE_TITLE_TOP);
//        mThemeTabView.setTabTitleStyle(TabTitleBuildFactory.STYLE_SUB_UI);
//        mThemeTabView.setOnPageChangeListener(this);
//
//        mMainService = (MainAbilityService) AppComm.register(mContext, BusinessServiceName.MAIN_SERVICE);
//        mAssistService = (AssistProcessService) AppComm.register(mContext, BusinessServiceName.BACKGROUD_SERVICE);
//
//        mSkinDataManager = (SettingSkinDataService) AppComm.register(mContext,
//                BusinessServiceName.SETTING_SKIN_SERVICE);
//
        buildTabView();
    }

    private void buildTabView() {
        // 此方法只运行一次，暂时通过第一个对象是否创建判断
        if (scrollSubTabView1 != null) {
            return;
        }

        scrollSubTabView1 = new ScrollSubTabView1(mContext, mViewManager);
        mTypeIndexMap = new SparseArray<Integer>();
//        Debug.waitForDebugger();
        mThemeTabView.addSubView(scrollSubTabView1);
        mTypeIndexMap.put(SubTabView2.class.hashCode(), 0);

        scrollSubTabView2 = new ScrollSubTabView2(mContext, mViewManager);
        mThemeTabView.addSubView(scrollSubTabView2);
        mTypeIndexMap.put(SubTabView2.class.hashCode(), 1);

    }

    private void initView() {
        buildTabView();
        switchViewForType();
//        checkReloadLocal();
    }


    private void switchViewForType() {
        int index = 0;
        boolean fromOther = true;

        MyIntent intent = new MyIntent();
        intent.putExtra(PageTabView.PAGETABVIEW_SWITCH_SMOOTH_SCROLL, false);
//        intent.putExtra(Constants.TAB_VIEW_BE_SWITCHED_FROM_OTHER, fromOther);
        mThemeTabView.switchToSubView(index, intent);

        mLastIndex = index;
    }

    @Override
    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2) {

    }

    @Override
    public void onPageSelected(int paramInt) {

    }

    @Override
    public void onPageScrollStateChanged(int paramInt) {

    }
}
