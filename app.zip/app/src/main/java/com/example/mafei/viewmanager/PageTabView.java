package com.example.mafei.viewmanager;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;

import com.example.mafei.viewmanager.navigator.ITabHostContentView;
import com.example.mafei.viewmanager.view.MyIntent;
import com.example.mafei.viewmanager.view.TabView;
import com.example.mafei.viewmanager.view
        .ViewPager;

import java.util.ArrayList;

/**
 * Created by mafei on 2017/2/13.
 */

public class PageTabView extends TabView implements ViewPager.OnPageChangeListener {

    public static final String PAGETABVIEW_SWITCH_SMOOTH_SCROLL = "com.iflytek.inputmethod.smoothscroll";

    private ViewPager.OnPageChangeListener mListener;

    public PageTabView(Context context, int style) {
        super(context, style);
    }

    @Override
    protected void initContentView() {
        mContentView = new ViewPager(mContext);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        mContentView.setLayoutParams(layoutParams);
        ((ViewPager) mContentView).setOnPageChangeListener(this);
    }

    @Override
    protected void initTitleView() {
        super.initTitleView();
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, (int) mContext.getResources().getDimension(
                R.dimen.DIP_50));
        mTitleView.setLayoutParams(params);
        mTitleView.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.setting_sub_tab_bg));
    }

    @Override
    public View getTabView() {
        return this;
    }

    @Override
    public void addSubView(int index, ITabHostContentView subTabView) {
        super.addSubView(index, subTabView);
        updateAdapter();
    }

    @Override
    public void addSubView(ITabHostContentView subTabView) {
        super.addSubView(subTabView);
        updateAdapter();
    }

    private void updateAdapter() {
        ArrayList<View> childs = new ArrayList<View>();
        for (ITabHostContentView subView : mSubViews) {
            childs.add(subView.getView());
        }
        mContentView.removeAllViews();
        ViewPagerAdapter viewPageAdapter = (ViewPagerAdapter) ((ViewPager) mContentView).getAdapter();
        if (viewPageAdapter == null) {
            viewPageAdapter = new ViewPagerAdapter(childs);
            ((ViewPager) mContentView).setAdapter(viewPageAdapter);
        } else {
            viewPageAdapter.updateViews(childs);
        }
        viewPageAdapter.notifyDataSetChanged();
    }

    public void setOnPageChangeListener(ViewPager.OnPageChangeListener listener) {
        mListener = listener;
    }

    @Override
    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2) {
        if (mListener != null) {
            mListener.onPageScrolled(paramInt1, paramFloat, paramInt2);
        }
    }

    @Override
    public void onPageSelected(int paramInt) {
        if (mCurrIndex != paramInt) {
            switchToSubView(paramInt);
        }
    }

    @Override
    protected void switchToSubContent(int index, MyIntent intent) {
        if (mContentView != null) {
            ITabHostContentView subView = mSubViews.get(index);
            boolean smoothScroll = true;
            if (intent != null) {
                smoothScroll = intent.getBooleanExtra(PAGETABVIEW_SWITCH_SMOOTH_SCROLL, true);
            }
            ((ViewPager) mContentView).setCurrentItem(index, smoothScroll);
            subView.onSelected(intent);
            if (mListener != null) {
                mListener.onPageSelected(index);
            }
        }
    }

    @Override
    protected void removeSubContent(int index) {
        super.removeSubContent(index);
        updateAdapter();
    }

    @Override
    public void onPageScrollStateChanged(int paramInt) {
        if (mListener != null) {
            mListener.onPageScrollStateChanged(paramInt);
        }

    }

}
