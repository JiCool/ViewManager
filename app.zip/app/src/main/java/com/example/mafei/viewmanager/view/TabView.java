package com.example.mafei.viewmanager.view;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.example.animationlibrary.library.Animators;
import com.example.mafei.viewmanager.R;
import com.example.mafei.viewmanager
        .TabTitleBuildFactory;
import com.example.mafei.viewmanager.navigator.ITabHostContentView;

import java.util.ArrayList;

/**
 * Created by mafei on 2017/2/13.
 */

public class TabView extends LinearLayout implements ITabView, View.OnClickListener {

    public static final int STYLE_TITLE_TOP = 1;

    public static final int STYLE_TITLE_BOTTOM = 2;

    private static final String TAG = "TabView";
    protected Context mContext;

    protected LinearLayout mTitleView;
    protected ViewGroup mContentView;

    /**
     * 所有的子view的titleview集合
     */
    protected ArrayList<ITabTitle> mTitles;

    /**
     * 所有的子view的titleview集合
     */
    protected ArrayList<View> mTitleViews;

    /**
     * 所有的子view集合
     */
    protected ArrayList<ITabHostContentView> mSubViews;

    protected int mCurrIndex = -1;

    private int mTitleStyle = TabTitleBuildFactory.STYLE_MAIN_UT;

    public TabView(Context context, int style) {
        super(context);
        mContext = context;
        setOrientation(VERTICAL);
        initTitleView();
        initContentView();
        if (style == STYLE_TITLE_TOP) {
            addView(mTitleView);
            addView(mContentView);
        } else {
            addView(mContentView);
            addView(mTitleView);
        }
    }

    @Override
    public void addSubView(ITabHostContentView subTabView) {
        if (mSubViews == null) {
            mSubViews = new ArrayList<ITabHostContentView>();
        }
        mSubViews.add(subTabView);
        mContentView.addView(subTabView.getView());
        addTitle(-1, subTabView);
    }

    @Override
    public void removeSubView(ITabHostContentView subTabView) {
        if (mSubViews == null || mSubViews.isEmpty()) {
            return;
        }
        int index = mSubViews.indexOf(subTabView);
        removeSubView(index);
    }

    @Override
    public void switchToSubView(int index) {
        switchToSubView(index, null);
    }

    @Override
    public void switchToSubView(int index, MyIntent intent) {

        if (!checkIndexValid(index)) {
            return;
        }

        if (mCurrIndex != -1) {
            ITabTitle lastTitle = mTitles.get(mCurrIndex);
            lastTitle.setState(TitleState.STATE_NORMAL);
        }

        // 上个子view非选中
        if (mCurrIndex != -1) {
            ITabHostContentView lastSubView = mSubViews.get(mCurrIndex);
            lastSubView.onUnSelected();
        }

        mCurrIndex = index;
        // 切换到下个子view
        switchToSubTitle(index);
        switchToSubContent(index, intent);
    }

    protected void switchToSubTitle(int index) {
        ITabTitle title = mTitles.get(index);
        title.setState(TitleState.STATE_SELECTED);
    }

    protected void switchToSubContent(int index, MyIntent intent) {
        // View content = subView.getView();
        int size = mContentView.getChildCount();

        for (int i = 0; i < size; i++) {
            View view = mContentView.getChildAt(i);
            if (i == index) {
                view.setVisibility(View.VISIBLE);
            } else {
                view.setVisibility(View.GONE);
            }
        }

        ITabHostContentView subView = mSubViews.get(index);
        subView.onSelected(intent);
    }

    /**
     * 增加子view,只允许在当前list中间或尾部插入，不允许子view间有空
     */
    @Override
    public void addSubView(int index, ITabHostContentView subTabView) {

        if (mSubViews == null && index != 0) {
            throw new IndexOutOfBoundsException("mSubViews is null but index is not 0");
        }

        if (mSubViews == null) {
            mSubViews = new ArrayList<ITabHostContentView>();
        }

        if (index < 0 || index > mSubViews.size()) {
            throw new IndexOutOfBoundsException("mSubViews size is: " + mSubViews.size() + "but index is" + index);
        }

        mSubViews.add(index, subTabView);
        mContentView.addView(subTabView.getView(), index);
        addTitle(index, subTabView);
    }

    @Override
    public void removeSubView(int index) {

        if (!checkIndexValid(index)) {
            return;
        }
        if (mTitles != null) {
            mTitles.remove(index);
        }
        if (mTitleView != null) {
            mTitleView.removeViewAt(index);
        }
        if (mTitleViews != null) {
            mTitleViews.remove(index);
        }
        removeSubContent(index);
        // 如果移除的是当前显示的怎么办
        if (mCurrIndex == index) {
            if (mSubViews.size() == 0) {
                mCurrIndex = -1;
            } else {
                // 恢复到默认
                switchToSubView(0);
            }
        } else if (mCurrIndex > index) {
            mCurrIndex--;
        }
    }

    protected void removeSubContent(int index) {
        mSubViews.remove(index);
        mContentView.removeViewAt(index);
    }

    public void setTabTitleStyle(int style) {
        mTitleStyle = style;
    }

    protected void initContentView() {
        mContentView = new LinearLayout(getContext());
        LayoutParams contentLayoutParams = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
        contentLayoutParams.weight = 1.0f;
        mContentView.setLayoutParams(contentLayoutParams);
        mContentView.setBackgroundColor(getContext().getResources().getColor(R.color.tab_background_color));
        // addView(mContentView);
    }

    protected void initTitleView() {
        mTitleView = new LinearLayout(getContext());
        LayoutParams params = new LayoutParams(LayoutParams.FILL_PARENT,
                (int) mContext.getResources().getDimension(R.dimen.common_tab_bottom_title_height));
        mTitleView.setLayoutParams(params);
        mTitleView.setOrientation(LinearLayout.HORIZONTAL);
        mTitleView.setBackgroundResource(R.drawable.setting_tab_bottom_bg);
        // addView(mTitleView);
    }

    /**
     * index==-1，在后面追加；index不是-1，就相应增加
     *
     * @param index
     * @param subTabView
     */
    private void addTitle(int index, ITabHostContentView subTabView) {
        if (mTitles == null) {
            mTitles = new ArrayList<ITabTitle>();
        }

        ITabTitle title = TabTitleBuildFactory.getTabTitle(getContext(), mTitleStyle);

        title.getView().setOnClickListener(this);

        int dividerIndex = -1;
        int viewIndex = -1;
        int titleIndex = -1;
        View divider = null;
        // 不需要考虑分隔符
        if (mTitles.size() == 0) {
            // 此时index必为0
            titleIndex = 0;
            viewIndex = 0;
        } else {
            // 需要考虑分割符
            divider = TabTitleBuildFactory.getTitleDivider(getContext(), mTitleStyle);
            if (divider != null) {
                // 有分隔符
                if (index != -1) {
                    titleIndex = index;
                    viewIndex = index * 2;
                    dividerIndex = index * 2 + 1;
                } else {
                    titleIndex = mTitles.size();
                    dividerIndex = (mTitles.size() - 1) * 2 + 1;
                    viewIndex = (mTitles.size() - 1) * 2 + 2;
                }

            } else {
                // 没有分隔符
                if (index != -1) {
                    titleIndex = index;
                    viewIndex = index;
                } else {
                    titleIndex = mTitles.size();
                    viewIndex = mTitles.size();
                }
            }
        }

        if (titleIndex != -1) {
            mTitles.add(titleIndex, title);
        }

        if (dividerIndex != -1 && divider != null) {
            mTitleView.addView(divider, dividerIndex);
        }

        if (viewIndex != -1) {
            mTitleView.addView(title.getView(), viewIndex);
            if (mTitleViews == null) {
                mTitleViews = new ArrayList<View>();
            }
            mTitleViews.add(titleIndex, title.getView());
        }

    }

    protected boolean checkIndexValid(int index) {
        if (mSubViews == null) {
            return false;
        }

        if (index < 0 || index >= mSubViews.size()) {
            return false;
        }


        return true;
    }

    protected boolean isSubViewEmpty() {
        if (mSubViews == null) {
            return true;
        }

        if (mSubViews.isEmpty()) {
            return true;
        }

        return false;
    }

    @Override
    public View getTabView() {
        return this;
    }

    @Override
    public void lightenSubTab(int index) {
        if (!checkIndexValid(index)) {
            return;
        }

        ITabTitle title = mTitles.get(index);

        if (title == null) {
            return;
        }

        title.light();
    }

    @Override
    public void onClick(View v) {
        int index = mTitleViews.indexOf(v);
        if (index != mCurrIndex) {
            switchToSubView(index);
        }
    }


    @Override
    public View getView() {
        // TODO Auto-generated method stub
        return this;
    }

    @Override
    public void createView(MyIntent intent) {
        if (isSubViewEmpty()) {
            return;
        }
        for (ITabHostContentView subTabView : mSubViews) {
            subTabView.createView(intent);
        }
    }

    @Override
    public void resumeView() {
        if (isSubViewEmpty()) {
            return;
        }

        if (mCurrIndex == -1)
        {
            mCurrIndex = 0;
        }
        ITabHostContentView subView = mSubViews.get(mCurrIndex);
        subView.resumeView();
    }

    /**
     * 只转发给当前的
     */
    @Override
    public void hideView() {

        if (isSubViewEmpty()) {
            return;
        }

        if (mCurrIndex != -1) {
            ITabHostContentView subView = mSubViews.get(mCurrIndex);
            subView.hideView();
        }
        // for (ISubTabView subTabView : mSubViews) {
        // subTabView.hideView();
        // }
    }

    /**
     * 这几个动作是要全部转发
     */
    @Override
    public void destroyView() {
        if (isSubViewEmpty()) {
            return;
        }
        for (ITabHostContentView subTabView : mSubViews) {
            subTabView.destroyView();
        }
    }

    @Override
    public void removeAllSubView() {
        if (mTitles != null) {
            mTitles.clear();
        }

        if (mTitleView != null) {
            mTitleView.removeAllViews();
        }

        if (mSubViews != null) {
            mSubViews.clear();
        }

        if (mContentView != null) {
            mContentView.removeAllViews();
        }

        mCurrIndex = -1;

    }

    /**
     * 只转发给当前的
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        if (isSubViewEmpty()) {
            return;
        }

        if (mCurrIndex != -1) {
            ITabHostContentView subView = mSubViews.get(mCurrIndex);
            subView.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    public void setIntent(MyIntent intent) {

    }

    @Override
    public ViewLaunchMode getLaunchMode() {
        return ViewLaunchMode.Standard;
    }
private int mViewFlag = 0;
    @Override
    public int getViewFlag() {
        return mViewFlag;
    }

    @Override
    public void setViewFlag(int flag) {
        mViewFlag = flag;
    }

    @Override
    public void setResult(int resultCode, MyIntent intent) {

    }



    @Override
    public void onViewResult(int requestCode, int resultCode, MyIntent intent) {

    }


    @Override
    public void cancelLight(int index) {
        if (!checkIndexValid(index)) {
            return;
        }

        ITabTitle title = mTitles.get(index);

        if (title == null) {
            return;
        }

        title.cancelLight();

    }


    private int mRequestCode;
    @Override
    public void setRequestCode(int requestCode) {
        mRequestCode = requestCode;
    }

    @Override
    public int getRequestCode() {
        return mRequestCode;
    }

    @Override
    public Animators getEnterAnimator() {
        return null;
    }

    @Override
    public Animators getExitAnimator() {
        return null;
    }

}
